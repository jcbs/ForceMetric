This is a short manual how to run ForceMetric on linux.

The dependencies are:
